create procedure emp_hiredate_proc (
    id EMPLOYEES.EMPLOYEE_ID% type,
    result in out varchar2
) is
    counts number;
    workyears number;
    no_one exception;
begin
    select count(*) into counts from EMPLOYEES where EMPLOYEE_ID = id;
    select ROUND((sysdate-HIRE_DATE)/365) into workyears from EMPLOYEES where EMPLOYEE_ID = id;

    if counts > 0 then
        result := workyears || '년 근무 함';
    else
        raise no_one;
    end if;

    exception
    when no_one then
        result := 'User doesnt exists';
    when others then
        result := 'Error occurred';
end;
/

