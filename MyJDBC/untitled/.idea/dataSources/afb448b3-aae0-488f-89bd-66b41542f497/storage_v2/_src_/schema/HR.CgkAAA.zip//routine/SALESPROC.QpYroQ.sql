create procedure salesProc (
    s SALES.SNO% type,
    n SALES.NAME% type,
    t SALES.TOTAL% type,
    p SALES.PRICE% type
) is
    today date;
    counts number;
    total number;
begin
    select sysdate into today from dual;
    select count(*) into counts from DAY_OF_SALES where regdate = today;

    if counts > 0 then
        select (FINAL_TOTAL + p) into total from day_of_sales;
        update DAY_OF_SALES set FINAL_TOTAL = total where regdate = today;
    else
        insert into DAY_OF_SALES values (today, p);
    end if;
end;
/

