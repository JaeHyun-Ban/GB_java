create procedure new_job_proc (
    p_job_id in JOBS.JOB_ID% type,
    p_job_title in JOBS.JOB_TITLE% type,
    p_job_min_salary in JOBS.MIN_SALARY% type,
    p_job_max_salary in JOBS.MAX_SALARY% type
) is
    v_exists boolean := false;
    begin
        v_exists := (select count(*) from JOBS where JOB_ID = p_job_id);

        if v_exists = 0 then
            insert into JOBS(job_id, job_title, min_salary, max_salary)
            VALUES (p_job_id, p_job_title, p_job_min_salary, p_job_max_salary);
        else
            update JOBS set JOB_TITLE = p_job_title,
                            MIN_SALARY = p_job_min_salary,
                            MAX_SALARY = p_job_max_salary
            WHERE JOB_ID = p_job_id;
        end if;
        commit;
    end;
/

