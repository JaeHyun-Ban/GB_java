create procedure guguProc (
    num1 number,
    num2 number
) is
begin
    DBMS_OUTPUT.PUT_LINE(num1 || ' * ' || num2 || ' = ' || num1 * num2);
end;
/

