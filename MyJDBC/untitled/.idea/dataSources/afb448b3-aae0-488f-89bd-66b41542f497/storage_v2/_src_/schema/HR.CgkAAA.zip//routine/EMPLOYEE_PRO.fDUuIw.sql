create procedure employee_pro (
    job in EMPLOYEES.JOB_ID% type
) is
    v_count number := 0;
    v_total number := 0;
begin
    select count(*), sum(SALARY)
        into v_count, v_total
    from EMPLOYEES
        where JOB_ID = job;

    if v_count = 0 then
        DBMS_OUTPUT.PUT_LINE(job || '는 없습니다');
    else
        DBMS_OUTPUT.PUT_LINE(job || ' 급여의 합: ' || v_total);
    end if;
end;
/

