create procedure deptsProc (
    flag varchar2,
    di DEPTS.DEPARTMENT_ID% type,
    dn DEPTS.DEPARTMENT_NAME% type,
    mi DEPTS.MANAGER_ID% type,
    li DEPTS.LOCATION_ID% type
) is
    no_command exception;
begin
    if flag = 'I' then
        insert into DEPTS values (di, dn, mi, li);
        commit;
    elsif flag = 'U' then
        update DEPTS set DEPARTMENT_NAME = dn, manager_id = mi, location_id = li where DEPARTMENT_ID = di;
        commit;
    elsif flag = 'D' then
        delete from DEPTS where DEPARTMENT_ID = di;
        commit;
    else
        raise no_command;
    end if;

exception
    when no_command then
        DBMS_OUTPUT.PUT_LINE('wrong commandline');
    when others then
        DBMS_OUTPUT.PUT_LINE('error occurred');
end;
/

