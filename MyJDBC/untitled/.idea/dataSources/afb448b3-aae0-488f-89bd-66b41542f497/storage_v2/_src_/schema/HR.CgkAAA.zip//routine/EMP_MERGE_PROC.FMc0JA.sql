create procedure emp_merge_proc (
    ei EMPLOYEES.EMPLOYEE_ID% type,
    ln EMPLOYEES.LAST_NAME% type,
    e EMPLOYEES.EMAIL% type,
    hd EMPLOYEES.HIRE_DATE% type,
    ji EMPLOYEES.JOB_ID% type
) is
    counts number;
begin
    select count(*) into counts from EMPS where EMPLOYEE_ID = ei;

    if counts > 0 then
        update EMPS
        set LAST_NAME = ln, EMAIL = e, HIRE_DATE = hd, JOB_ID = ji
        where EMPLOYEE_ID = ei;
    else
        insert into EMPS(employee_id, last_name, email, hire_date, job_id)
        values (ei, ln, e, hd, ji);
    end if;
end;
/

