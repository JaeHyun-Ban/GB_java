create trigger TRG_TEST
    after update or delete
    on TBL_TEST
    for each row
begin

    if updating then
        DBMS_OUTPUT.PUT_LINE('트리거 update 실행');
    elsif deleting then
        DBMS_OUTPUT.PUT_LINE('트리거 delete 실행');
    end if;
end;
/

